export default class Business {
    person_name: String;
    business_name: String;
    business_gst_number: Number;
}
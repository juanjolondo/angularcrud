import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crud-get',
  templateUrl: './crud-get.component.html',
  styleUrls: ['./crud-get.component.css']
})
export class CrudGetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

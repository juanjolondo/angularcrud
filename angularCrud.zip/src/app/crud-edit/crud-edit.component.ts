import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crud-edit',
  templateUrl: './crud-edit.component.html',
  styleUrls: ['./crud-edit.component.css']
})
export class CrudEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
